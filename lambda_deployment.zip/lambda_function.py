"""Lambda entry point for Danny AI."""
import os
import json

# Set environment variables for Lambda
os.environ.setdefault("ANTHROPIC_API_KEY", os.environ.get("ANTHROPIC_API_KEY", ""))
# Use DANNY_REGION since AWS_REGION is reserved
os.environ.setdefault("AWS_REGION", os.environ.get("DANNY_REGION", os.environ.get("AWS_REGION", "us-west-2")))
os.environ.setdefault("USE_BEDROCK", "false")

from danny.lambda_handler import handler as danny_handler

def handler(event, context):
    """Main Lambda handler."""
    return danny_handler(event, context)
